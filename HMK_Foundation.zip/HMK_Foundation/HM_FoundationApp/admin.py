from django.contrib import admin
from HM_FoundationApp.models import Executive_Counsil,Adviser_Counsil,Add_News,Add_Image
# Register your models here.
admin.site.register(Executive_Counsil)
admin.site.register(Adviser_Counsil)
admin.site.register(Add_News)
admin.site.register(Add_Image)