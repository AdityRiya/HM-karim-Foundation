from django.contrib import admin
from HM_FoundationApp.models import Executive_Counsil,Adviser_Counsil
# Register your models here.
admin.site.register(Executive_Counsil)
admin.site.register(Adviser_Counsil)
